const firebaseConfig = {
  apiKey: "AIzaSyA4G5fc5ReC-FIJK_Pry3ebn9pImKW67c0",
  authDomain: "exam-ff58b.firebaseapp.com",
  databaseURL: "https://exam-ff58b.firebaseio.com",
  projectId: "exam-ff58b",
  storageBucket: "exam-ff58b.appspot.com",
  messagingSenderId: "285996744079",
  appId: "1:285996744079:web:988629f539bbb7abc35ffa"
};

firebase.initializeApp(firebaseConfig);