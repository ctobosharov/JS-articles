import extend from '../utils/context.js';
import models from '../models/index.js';
import docModifier from '../utils/doc-modified.js';

export default {
    get: {
        create(context) {
            extend(context).then(function () {
                this.partial('../views/article/create.hbs')
            })
        }
    },
    post: {

        //TODO
        create(context) {
            const data = { ...context.params, title, category, content };

            models.article.create(data).then((resonse) => {
                console.log(resonse);
                context.redirect('#/home')
            }).catch((e) => console.error(e));
        }
    },
    del: {
        close(context) {
            const { articleId } = context.params;

            models.article.close(articleId).then((response) => {
                context.redirect('#/home');
            })
        }
    }
};