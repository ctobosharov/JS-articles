export default {
    create(data) {
        return firebase.firestore().collection('articles').add(data)
    },
    close(id) {
        return firebase.firestore().collection('articles').doc(id).delete()
    }
};